<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Producto</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #f06, #f90);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            color: #333;
        }
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 500px;
            margin: 20px;
            text-align: center;
        }
        .form-container h1 {
            margin-bottom: 20px;
            font-size: 28px;
            color: #f06;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .message, .error {
            font-size: 18px;
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 8px;
            font-weight: bold;
        }
        .message {
            color: #28a745;
            background-color: #d4edda;
        }
        .error {
            color: #dc3545;
            background-color: #f8d7da;
        }
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 600;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: #f06;
            outline: none;
        }
        .form-group button {
            background-color: #f06;
            border: none;
            color: #fff;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            width: 100%;
            margin-top: 10px;
        }
        .form-group button:hover {
            background-color: #d04;
            transform: translateY(-2px);
        }
        .form-group button.delete-btn {
            background-color: #dc3545;
        }
        .form-group button.delete-btn:hover {
            background-color: #c82333;
        }
        .back-btn {
            background-color: #333;
            border: none;
            color: #fff;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-align: center;
            text-decoration: none;
            display: block;
            margin: 30px auto 0;
            width: 100%;
            max-width: 200px;
        }
        .back-btn:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Modificar Producto</h1>

        <?php
        $mensaje = '';
        $error = '';
        $product = null;

        // Conexión a la base de datos
        $conn = new mysqli("localhost", "root", "", "productos");

        // Verificar conexión
        if ($conn->connect_error) {
            die("<p class='error'>Conexión fallida: " . $conn->connect_error . "</p>");
        }

        // Búsqueda de producto por ID
        if (isset($_POST['search'])) {
            $productId = intval($_POST['search_id']);

            if ($productId > 0) {
                $result = $conn->query("SELECT * FROM postres WHERE id = $productId");

                if ($result->num_rows > 0) {
                    $product = $result->fetch_assoc();
                } else {
                    $error = "Producto con ID $productId no encontrado.";
                }
            } else {
                $error = "ID del producto no válido.";
            }
        }

        // Modificar producto
        if (isset($_POST['update'])) {
            $nombre = $conn->real_escape_string($_POST['nombre']);
            $tipo = $conn->real_escape_string($_POST['tipo']);
            $ingredientes = $conn->real_escape_string($_POST['ingredientes']);
            $precio = floatval($_POST['precio']);
            $fecha = $conn->real_escape_string($_POST['fecha']);

            $updateQuery = "UPDATE postres SET nombre='$nombre', tipo='$tipo', ingredientes='$ingredientes', precio='$precio', fecha='$fecha' WHERE id=" . intval($_POST['id']);

            if ($conn->query($updateQuery) === TRUE) {
                $mensaje = "¡Producto modificado con éxito!";
            } else {
                $error = "Error al modificar el producto: " . $conn->error;
            }
        }

        $conn->close();
        ?>

        <!-- Mostrar el mensaje o error si existe -->
        <?php if (!empty($mensaje)): ?>
            <p class="message"><?php echo $mensaje; ?></p>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <!-- Formulario de búsqueda por ID -->
        <form action="" method="POST">
            <div class="form-group">
                <label for="search_id">Buscar por ID</label>
                <input type="number" id="search_id" name="search_id" required>
            </div>
            <div class="form-group">
                <button type="submit" name="search">Buscar Producto</button>
            </div>
        </form>

        <!-- Mostrar el formulario de modificación si se encontró el producto -->
        <?php if ($product): ?>
            <form action="" method="POST">
                <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                <div class="form-group">
                    <label for="nombre">Nombre del Producto</label>
                    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($product['nombre']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="tipo">Tipo</label>
                    <input type="text" id="tipo" name="tipo" value="<?php echo htmlspecialchars($product['tipo']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="ingredientes">Ingredientes</label>
                    <input type="text" id="ingredientes" name="ingredientes" value="<?php echo htmlspecialchars($product['ingredientes']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="precio">Precio</label>
                    <input type="number" id="precio" name="precio" step="0.01" value="<?php echo htmlspecialchars($product['precio']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="fecha">Fecha</label>
                    <input type="date" id="fecha" name="fecha" value="<?php echo htmlspecialchars($product['fecha']); ?>" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="update">Modificar Producto</button>
                    <button type="submit" name="delete" class="delete-btn" onclick="return confirm('¿Estás seguro de que deseas eliminar este producto?');">Eliminar Producto</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
    <!-- Botón de Regreso -->
    <a class="back-btn" href="index.php">Regresar al Menú Principal</a>
</body>
</html>
