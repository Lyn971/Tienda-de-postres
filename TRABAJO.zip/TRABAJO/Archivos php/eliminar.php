<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Producto</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f7f9;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            overflow: hidden;
        }
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            border: 2px solid #ff4d4d;
            box-sizing: border-box;
            position: relative;
            margin-bottom: 80px; /* Espacio para el botón */
        }
        .form-container h1 {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
            font-size: 28px;
            position: relative;
            padding-bottom: 10px;
            border-bottom: 3px solid #ff4d4d;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #555;
        }
        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: #ff4d4d;
            outline: none;
        }
        .form-group button {
            background-color: #ff4d4d;
            border: none;
            color: #fff;
            padding: 12px 25px;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
            display: block;
            margin: 20px auto;
        }
        .form-group button:hover {
            background-color: #e60000;
            transform: translateY(-2px);
        }
        .message {
            color: #ff4d4d;
            font-size: 18px;
            text-align: center;
            margin-top: 20px;
        }
        .back-btn {
            background-color: #63e3be;
            border: none;
            color: #fff;
            padding: 15px 30px;
            border-radius: 50px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s, box-shadow 0.3s;
            text-align: center;
            display: block;
            margin: 20px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
        }
        .back-btn:hover {
            background-color: #4dc4a0;
            transform: scale(1.05);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.4);
        }
        .back-btn::before {
            content: "←";
            font-size: 20px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Eliminar Producto</h1>
        <?php
        // Verificar si se ha enviado el formulario
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Conexión a la base de datos
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "productos";

            // Crear conexión
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Verificar conexión
            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            // Obtener el ID del producto a eliminar
            $id = $_POST['id'];

            // Preparar y ejecutar la consulta
            $sql = "DELETE FROM postres WHERE id = ?";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                die("Error al preparar la consulta: " . $conn->error);
            }

            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                echo "<p class='message'>¡Producto eliminado con éxito!</p>";
            } else {
                echo "<p class='message'>Error al eliminar el producto: " . $stmt->error . "</p>";
            }

            // Cerrar la declaración y la conexión
            $stmt->close();
            $conn->close();
        }
        ?>
        <form action="" method="POST">
            <div class="form-group">
                <label for="id">ID del Producto a Eliminar</label>
                <input type="number" id="id" name="id" min="1" required>
            </div>
            <div class="form-group">
                <button type="submit">Eliminar Producto</button>
            </div>
        </form>
    </div>
    <!-- Botón de Regreso -->
    <a class="back-btn" href="index.php">Regresar al Menú Principal</a>
</body>
</html>
