<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Compra con Cálculos y Condiciones</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #e8f4f8;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            color: #333;
            position: relative;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px; 
            margin: 20px;
            text-align: center;
        }
        .form-container h1 {
            margin-bottom: 20px;
            color: #ff69b4;
            font-size: 28px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .checkbox-group {
            border: 1px solid #c5e1a5;
            border-radius: 8px;
            padding: 15px;
            background-color: #e8f5e9;
            margin-bottom: 20px;
            text-align: left;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }
        input[type="number"], input[type="checkbox"], button {
            display: block;
            margin: 10px 0;
        }
        input[type="checkbox"] {
            margin-right: 10px;
        }
        button {
            background-color: #64b5f6; 
            color: #fff;
            border: none;
            cursor: pointer;
            padding: 12px 24px;
            border-radius: 6px;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #42a5f5; 
        }
        #result {
            margin-top: 20px;
            font-size: 18px;
            font-weight: bold;
            color: #333;
            text-align: center;
        }
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        .back-link a {
            text-decoration: none;
            color: #007bff; 
            font-size: 16px;
            font-weight: bold;
            transition: color 0.3s;
        }
        .back-link a:hover {
            color: #0056b3; 
        }
        .button-container {
            display: flex;
            justify-content: space-between;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Formulario de Compra</h1>
        <form id="price-form" method="post">
            <div class="checkbox-group">
                <label for="products">Selecciona los productos:</label>
                <input type="checkbox" id="product1" name="products[]" value="350">
                <label for="product1">Tarta de Manzana - $350</label>
                
                <input type="checkbox" id="product2" name="products[]" value="250">
                <label for="product2">Helado de Chocolate - $250</label>
                
                <input type="checkbox" id="product3" name="products[]" value="200">
                <label for="product3">Galletas de Chocolate - $200</label>
                
                <input type="checkbox" id="product4" name="products[]" value="150">
                <label for="product4">Pudín de Vainilla - $150</label>

                <input type="checkbox" id="product5" name="products[]" value="400">
                <label for="product5">Cheesecake - $400</label>
            </div>

            <label for="quantity">Cantidad (de cada producto):</label>
            <input type="number" id="quantity" name="quantity" min="1" value="1" required>

            <div class="button-container">
                <button type="submit">Calcular Total</button>
                <button type="button" id="clear-btn">Limpiar</button>
            </div>
        </form>
        <div id="result"></div>
        <div class="back-link">
            <a href="index.php">Regresar a la Página Principal</a>
        </div>
    </div>

    <script>
        document.getElementById('price-form').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const quantity = parseInt(document.getElementById('quantity').value, 10);
            const checkboxes = document.querySelectorAll('input[name="products[]"]:checked');
            let total = 0;
            let discount = 0;

            checkboxes.forEach(checkbox => {
                total += parseFloat(checkbox.value);
            });
            total *= quantity;

            if (checkboxes.length > 2) {
                discount = 0.1;
            }

            const totalWithDiscount = total - (total * discount);

            document.getElementById('result').innerText = 'Total a pagar: $' + totalWithDiscount.toFixed(2);
        });

        document.getElementById('clear-btn').addEventListener('click', function() {
            document.getElementById('price-form').reset();
            document.getElementById('result').innerText = '';
        });
    </script>
</body>
</html>
