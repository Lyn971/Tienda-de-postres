<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Búsqueda de Postres</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #e8f4f8;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100vh;
        }

        .search-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            text-align: center;
            border: 2px solid #ffd1dc;
        }

        .search-container h1 {
            margin-bottom: 20px;
            color: #ff69b4;
            font-size: 28px;
        }

        .search-container label {
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
            color: #666;
        }

        .search-container input[type="text"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 2px solid #a2d5f2;
            border-radius: 30px;
            font-size: 16px;
            transition: border-color 0.3s, box-shadow 0.3s;
            box-shadow: 0 0 5px rgba(162, 213, 242, 0.5);
        }

        .search-container input[type="text"]:focus {
            border-color: #66b2ff;
            box-shadow: 0 0 8px rgba(102, 178, 255, 0.7);
            outline: none;
        }

        .search-container input[type="submit"] {
            background-color: #ffb6c1;
            color: #ffffff;
            padding: 12px 20px;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        .search-container input[type="submit"]:hover {
            background-color: #ff69b4;
            transform: translateY(-2px);
        }

        .results {
            margin-top: 20px;
            padding: 20px;
            border-radius: 12px;
            background-color: #f0f8ff;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            text-align: left;
        }

        .results .card {
            background-color: #ffffff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .results .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .results h3 {
            margin-top: 0;
            font-size: 22px;
            color: #333;
        }

        .results p {
            margin: 5px 0;
            font-size: 14px;
            color: #666;
        }

        .delete-btn {
            background-color: #ff6666;
            color: #ffffff;
            padding: 8px 15px;
            border: none;
            border-radius: 30px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
            margin-top: 10px;
        }

        .delete-btn:hover {
            background-color: #ff3333;
            transform: translateY(-2px);
        }

        hr {
            border: none;
            border-top: 1px solid #ddd;
            margin: 20px 0;
        }

        .back-btn {
            background-color: #63e3be;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }

        .back-btn:hover {
            background-color: #4dc4a0;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="search-container">
        <h1>Buscar Postres</h1>
        <form method="GET" action="">
            <label for="search">Buscar por ID:</label>
            <input type="text" id="search" name="search" placeholder="Ingrese el ID del postre">
            <input type="submit" value="Buscar">
        </form>

        <div class="results">
            <?php
            // Conexión a la base de datos
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "productos";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Verifica si la conexión fue exitosa
            if ($conn->connect_error) {
                die("Conexión fallida: " . $conn->connect_error);
            }

            // Manejar eliminación de postre
            if (isset($_POST['delete_id'])) {
                $delete_id = $conn->real_escape_string($_POST['delete_id']);
                $delete_sql = "DELETE FROM postres WHERE id = '$delete_id'";
                if ($conn->query($delete_sql) === TRUE) {
                    echo "<h3>Postre eliminado exitosamente.</h3>";
                } else {
                    echo "<h3>Error al eliminar el postre: " . $conn->error . "</h3>";
                }
            }

            // Verifica si se ha enviado el formulario de búsqueda
            if (isset($_GET['search']) && !empty($_GET['search'])) {
                // Obtén el término de búsqueda del formulario
                $search_term = $_GET['search'];

                // Evita inyecciones SQL escapando caracteres especiales
                $search_term = $conn->real_escape_string($search_term);

                // Consulta SQL para buscar en la base de datos
                $sql = "SELECT * FROM postres WHERE id LIKE '%$search_term%'";

                // Ejecuta la consulta
                $result = $conn->query($sql);

                // Verifica si hay resultados
                if ($result->num_rows > 0) {
                    // Muestra los resultados
                    while($row = $result->fetch_assoc()) {
                        echo '<div class="card">';
                        echo "<h3>ID: " . $row["id"] . "</h3>";
                        echo "<p>Nombre: " . $row["nombre"] . "</p>";
                        echo "<p>Tipo: " . $row["tipo"] . "</p>";
                        echo "<p>Ingredientes: " . $row["ingredientes"] . "</p>";
                        echo "<p>Precio: $" . $row["precio"] . "</p>";
                        echo "<p>Fecha agregado: " . $row["fecha"] . "</p>";
                        echo '<form method="POST" action="">
                                <input type="hidden" name="delete_id" value="' . $row["id"] . '">
                                <input type="submit" class="delete-btn" value="Eliminar">
                              </form>';
                        echo '</div><hr>';
                    }
                } else {
                    echo "<h3>No se encontraron resultados.</h3>";
                }
            } else {
                echo "<h3>Por favor, ingrese un término de búsqueda.</h3>";
            }

            // Cierra la conexión
            $conn->close();
            ?>
        </div>
    </div>
    
    <!-- Botón de Regreso -->
    <a class="back-btn" href="index.php">Regresar al Menú Principal</a>
</body>
</html>
