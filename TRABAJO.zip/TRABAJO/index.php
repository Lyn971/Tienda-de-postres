<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Vertical Desplegable con Carrusel y Comentarios</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Open+Sans:wght@400;600&family=Pacifico&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4; /* Color de fondo más neutro */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            text-align: justify;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background: linear-gradient(135deg, #a2c2e4, #f7c6c7); /* Colores pastel azul y rosa */
            position: fixed;
            top: 0;
            left: -250px;
            transition: left 0.3s ease;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar.open {
            left: 0;
        }
        .sidebar-header {
            background-color: #a2c2e4; /* Azul pastel */
            color: #333;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            font-size: 24px;
            font-weight: 700;
            font-family: 'Pacifico', cursive;
        }
        .sidebar a {
            text-decoration: none;
            color: #333;
            display: block;
            padding: 15px;
            font-size: 18px;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background-color: #d0e6f4; /* Color azul pastel en hover */
        }
        .content {
            margin-left: 0;
            padding: 20px;
            flex: 1;
            transition: margin-left 0.3s;
        }
        .content.expanded {
            margin-left: 250px;
        }
        .toggle-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 28px;
            cursor: pointer;
            z-index: 1001;
            color: #333;
        }
        .carousel {
            position: relative;
            max-width: 100%;
            margin: 20px auto;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background: #fff;
        }
        .carousel-images {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }
        .carousel-images img {
            width: 100%;
            height: auto;
        }
        .carousel-buttons {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
        }
        .carousel-button {
            background-color: rgba(255, 255, 255, 0.8);
            border: none;
            color: #333;
            padding: 10px;
            cursor: pointer;
            font-size: 24px;
            border-radius: 50%;
            transition: background-color 0.3s;
        }
        .carousel-button:hover {
            background-color: rgba(255, 255, 255, 1);
        }
        #prev::before {
            content: '\f100';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
        }
        #next::before {
            content: '\f101';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
        }
        .divider {
            width: 100%;
            height: 10px;
            background: linear-gradient(135deg, #f7c6c7, #a2c2e4); /* Rosa y azul pastel */
            margin: 40px 0;
        }
        .comments-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            flex: 1;
            display: flex;
            flex-direction: column;
            margin-top: 20px;
        }
        .comments-section h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #f7c6c7; /* Rosa pastel */
            font-family: 'Pacifico', cursive;
        }
        .comments-list {
            margin-bottom: 20px;
            max-height: 300px;
            overflow-y: auto;
        }
        .comment {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .comment:last-child {
            border-bottom: none;
        }
        .comment .author {
            font-weight: 700;
            color: #d0e6f4; /* Azul pastel */
        }
        .comment .text {
            margin: 5px 0;
            color: #333;
        }
        .comment button {
            background-color: #d0e6f4; /* Azul pastel */
            border: none;
            color: #333;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .comment button:hover {
            background-color: #a2c2e4; /* Azul pastel */
        }
        .form-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .form-section textarea,
        .form-section input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .form-section button[type="submit"] {
            background-color: #f7c6c7; /* Rosa pastel */
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-section button[type="submit"]:hover {
            background-color: #f5a1a2; /* Rosa más intenso */
        }
        .social-links {
            margin-top: 20px;
            text-align: center;
        }
        .social-links a {
            text-decoration: none;
            color: #333;
            margin: 0 10px;
            font-size: 28px;
            transition: color 0.3s;
        }
        .social-links a:hover {
            color: #a2c2e4; /* Azul pastel */
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header" id="sidebar-toggle">
            ☰ Menú
        </div>
        <?php
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "productos";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consultar datos del menú
        $sql = "SELECT postres, enlace, nombre FROM productos";
        $result = $conn->query($sql);

        // Mostrar el menú
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<a href='" . htmlspecialchars($row["enlace"]) . "'>" . htmlspecialchars($row["nombre"]) . "</a>";
            }
        } else {
            echo "<a href='buscar.php'>Buscar los Postres</a>";
            echo "<a href='agregar.php'>Agregar más Postres</a>";
            echo "<a href='modificar.php'>Modificar los Postres</a>";
            echo "<a href='eliminar.php'>Eliminar Postres</a>";
            echo "<a href='descuento.php'>Formulario de compra</a>";
            echo "<a href='consulta.php'>Consulta General</a>";
        }

        // Cerrar la conexión
        $conn->close();
        ?>
    </div>
    <div class="content" id="content">
        <div class="toggle-btn" id="toggle-btn">
            ☰
        </div>

        <h1>Bienvenidos a Dulce Tentación</h1>

<p>En Dulce Tentación, nos apasiona endulzar tu vida con una variedad exquisita de postres que van desde clásicos hasta innovadores. Nuestra tienda es un paraíso para los amantes de los dulces, donde cada bocado cuenta una historia de sabor y calidad.</p>

<p>¿Qué Ofrecemos?</p>

<p>• Pasteles Artesanales: Desde tartas de frutas frescas hasta pasteles de chocolate decadente, nuestros pasteles son elaborados con ingredientes de la más alta calidad y con mucho amor.</p>

<p>• Cupcakes Creativos: Cada cupcake es una obra de arte, decorado a mano y disponible en una variedad de sabores, desde vainilla clásica hasta red velvet y más allá.</p>

<p>• Galletas Gourmet: Nuestras galletas son perfectas para cualquier ocasión, con opciones que van desde chispas de chocolate hasta combinaciones sorprendentes como lavanda y miel.</p>

<p>• Postres Especiales: Ofrecemos una selección de postres especiales como macarons, cheesecakes y brownies, ideales para regalar o para disfrutar en cualquier momento.</p>

        <!-- Carrusel de imágenes -->
        <div class="carousel">
            <div class="carousel-images">
                <img src="https://www.laespanolaaceites.com/wp-content/uploads/2019/06/tarta-de-bizcocho-con-manzana-1080x671.jpg" alt="Imagen 1">
                <img src="https://www.comedera.com/wp-content/uploads/2022/04/Helado-de-chocolate-sin-azucar-casero-shutterstock_1418765711.jpg" alt="Imagen 2">
                <img src="https://www.hersheyland.mx/content/dam/Hersheyland_Mexico/es_mx/recipes/recipe-images/navidad-2022/Galletas-milk-de-Hersheys.jpg" alt="Imagen 3">
                <img src="https://www.gmasivos.com/wp-content/uploads/2016/09/web.jpg" alt="Imagen 4">
                <img src="https://www.allrecipes.com/thmb/DHosjm3NundSDP1q6wWEEECYwr8=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/8419-easy-sour-cream-cheesecake-DDMFS-beauty-4x3-BG-2747-44b427d330aa41aa876269b1249698a0.jpg" alt="Imagen 5">
                <img src="https://storage.contextoganadero.com/s3fs-public/blog/field_image/2021-02/img_postreslechecondensada_1920x1280.jpg" alt="Imagen 6">
            </div>
            <div class="carousel-buttons">
                <button class="carousel-button" id="prev"></button>
                <button class="carousel-button" id="next"></button>
            </div>
        </div>
        <div class="divider"></div>

        <!-- Sección de comentarios -->
        <div class="comments-section">
            <h2>Comentarios</h2>
            <div class="comments-list" id="comments-list">
                <!-- Comentarios serán añadidos aquí dinámicamente -->
            </div>
            <div class="form-section">
                <form id="comment-form">
                    <input type="text" id="comment-author" placeholder="Tu nombre" required>
                    <textarea id="comment-text" rows="4" placeholder="Escribe tu comentario aquí..." required></textarea>
                    <button type="submit">Enviar Comentario</button>
                </form>
            </div>
        </div>

        <div class="social-links">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-youtube"></a>
        </div>
    </div>

    <script>
        // Toggle sidebar
        const sidebar = document.getElementById('sidebar');
        const content = document.getElementById('content');
        const toggleBtn = document.getElementById('toggle-btn');

        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            content.classList.toggle('expanded');
        });

        // Carrusel
        let index = 0;
        const images = document.querySelectorAll('.carousel-images img');
        const totalImages = images.length;

        document.getElementById('next').addEventListener('click', () => {
            index = (index + 1) % totalImages;
            updateCarousel();
        });

        document.getElementById('prev').addEventListener('click', () => {
            index = (index - 1 + totalImages) % totalImages;
            updateCarousel();
        });

        function updateCarousel() {
            const offset = -index * 100;
            document.querySelector('.carousel-images').style.transform = `translateX(${offset}%)`;
        }

        // Comentarios
        const commentForm = document.getElementById('comment-form');
        const commentsList = document.getElementById('comments-list');

        commentForm.addEventListener('submit', (event) => {
            event.preventDefault();
            const author = document.getElementById('comment-author').value;
            const text = document.getElementById('comment-text').value;

            if (author && text) {
                const commentDiv = document.createElement('div');
                commentDiv.className = 'comment';
                commentDiv.innerHTML = `
                    <div>
                        <div class="author">${author}</div>
                        <div class="text">${text}</div>
                    </div>
                    <button class="delete-btn">Eliminar</button>
                `;
                commentsList.appendChild(commentDiv);

                commentForm.reset();
            }
        });

        commentsList.addEventListener('click', (event) => {
            if (event.target.classList.contains('delete-btn')) {
                event.target.parentElement.remove();
            }
        });
    </script>
       <div id="sfclhr1q9khxtb7tfn484hr2xmcs1m8gnfj"></div>
    <script type="text/javascript" src="https://counter2.optistats.ovh/private/counter.js?c=lhr1q9khxtb7tfn484hr2xmcs1m8gnfj&down=async" async>
    </script><noscript><a href="https://www.contadorvisitasgratis.com" title="contador de visitas gratis para blog">
    <img src="https://counter2.optistats.ovh/private/contadorvisitasgratis.php?c=lhr1q9khxtb7tfn484hr2xmcs1m8gnfj" 
    border="0" title="contador de visitas gratis para blog" alt="contador de visitas gratis para blog"></a></noscript>
        
</body>
</html>
