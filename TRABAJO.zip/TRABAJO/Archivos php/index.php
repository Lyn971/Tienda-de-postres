<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú Vertical Desplegable con Carrusel y Comentarios</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #333;
            position: fixed;
            top: 0;
            left: -250px;
            transition: left 0.3s ease;
            overflow-y: auto;
            z-index: 1000;
        }
        .sidebar.open {
            left: 0;
        }
        .sidebar-header {
            background-color: #444;
            color: #fff;
            padding: 15px;
            text-align: center;
            cursor: pointer;
        }
        .sidebar a {
            text-decoration: none;
            color: #fff;
            display: block;
            padding: 15px;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        .sidebar a:hover {
            background-color: #555;
        }
        .content {
            margin-left: 0;
            padding: 20px;
            flex: 1;
            transition: margin-left 0.3s;
            display: flex;
            flex-direction: column;
        }
        .content.expanded {
            margin-left: 250px;
        }
        .toggle-btn {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 24px;
            cursor: pointer;
            z-index: 1001;
        }
        .carousel {
            position: relative;
            max-width: 100%;
            margin: 20px auto;
            overflow: hidden;
            border: 2px solid #ddd;
            max-width: 800px;
        }
        .carousel-images {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }
        .carousel-images img {
            width: 100%;
            height: auto;
        }
        .carousel-buttons {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
        }
        .carousel-button {
            background-color: none;
            border: none;
            color: #63e3be;
            padding: 10px;
            cursor: pointer;
            font-size: 20px;
            transition: background-color 0.3s;
        }
        .carousel-button:hover {
            background-color: rgba(0, 0, 0, 0.2);
        }
        #prev::before {
            content: '\f100';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
        }
        #next::before {
            content: '\f101';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
        }
        .full-width-divider {
            width: 100%;
            height: 10px;
            background-color: #fdcf76;
            margin: 40px 0;
        }
        .comments-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin-top: 20px;
        }
        .comments-section h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .comments-list {
            margin-bottom: 20px;
            max-height: 300px;
            overflow-y: auto;
        }
        .comment {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .comment:last-child {
            border-bottom: none;
        }
        .comment .author {
            font-weight: bold;
        }
        .comment .text {
            margin: 5px 0;
        }
        .comment button {
            background-color: #ff4d4d;
            border: none;
            color: #fff;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .comment button:hover {
            background-color: #e60000;
        }
        .form-section {
            background-color: #fff;
            padding: 20px;
            border-radius: 4px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .form-section textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            resize: vertical;
        }
        .form-section button[type="submit"] {
            background-color: #63e3be;
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .form-section button[type="submit"]:hover {
            background-color: #4dc4a0;
        }
        .social-links {
            margin-top: 20px;
            text-align: center;
        }
        .social-links a {
            text-decoration: none;
            color: #333;
            margin: 0 10px;
            font-size: 24px;
            transition: color 0.3s;
        }
        .social-links a:hover {
            color: #63e3be;
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header" id="sidebar-toggle">
            ☰ Menú
        </div>
        <?php
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "productos";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Consultar datos del menú
        $sql = "SELECT postres, enlace, nombre FROM productos";
        $result = $conn->query($sql);

        // Mostrar el menú
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<a href='" . htmlspecialchars($row["enlace"]) . "'>" . htmlspecialchars($row["nombre"]) . "</a>";
            }
        } else {
            echo "<a href='buscar.php'>Buscar los Postres</a>";
            echo "<a href='agregar.php'>Agregar más Postres</a>";
            echo "<a href='modificar.php'>Modificar los Postres</a>";
            echo "<a href='eliminar.php'>Eliminar Postres</a>";
            echo "<a href='consulta.php'>Consulta General</a>";
        }

        // Cerrar la conexión
        $conn->close();
        ?>
    </div>
    <div class="content" id="content">
        <div class="toggle-btn" id="toggle-btn">
            ☰
        </div>

        <h1>Bienvenidos a Dulce Tentación</h1>

        <p>En Dulce Tentación, nos apasiona endulzar tu vida con una variedad exquisita de postres que van desde clásicos hasta innovadores. Nuestra tienda es un paraíso para los amantes de los dulces, donde cada bocado cuenta una historia de sabor y calidad.</p>

        <p>¿Qué Ofrecemos?</p>

        <p>• Pasteles Artesanales: Desde tartas de frutas frescas hasta pasteles de chocolate decadente, nuestros pasteles son elaborados con ingredientes de la más alta calidad y con mucho amor.</p>

        <p>• Cupcakes Creativos: Cada cupcake es una obra de arte, decorado a mano y disponible en una variedad de sabores, desde vainilla clásica hasta red velvet y más allá.</p>

        <p>• Galletas Gourmet: Nuestras galletas son perfectas para cualquier ocasión, con opciones que van desde chispas de chocolate hasta combinaciones sorprendentes como lavanda y miel.</p>

        <p>• Postres Especiales: Ofrecemos una selección de postres especiales como macarons, cheesecakes y brownies, ideales para regalar o para disfrutar en cualquier momento.</p>

        <!-- Carrusel de Imágenes -->
        <div class="carousel">
            <div class="carousel-images">
                <img src="https://www.laespanolaaceites.com/wp-content/uploads/2019/06/tarta-de-bizcocho-con-manzana-1080x671.jpg" alt="Imagen 1">
                <img src="https://www.comedera.com/wp-content/uploads/2022/04/Helado-de-chocolate-sin-azucar-casero-shutterstock_1418765711.jpg" alt="Imagen 2">
                <img src="https://www.hersheyland.mx/content/dam/Hersheyland_Mexico/es_mx/recipes/recipe-images/navidad-2022/Galletas-milk-de-Hersheys.jpg" alt="Imagen 3">
                <img src="https://www.unileverfoodsolutions.es/dam/global-ufs/mcos/SPAIN/calcmenu/recipes/ES-recipes/general/pudding-de-vainilla-carte-dor/main-header.jpg" alt="Imagen 4">
                <img src="https://www.splenda.com/wp-content/uploads/2020/05/american-classic-cheesecake-2000x1000.jpg" alt="Imagen 5">
                <img src="https://storage.contextoganadero.com/s3fs-public/blog/field_image/2021-02/img_postreslechecondensada_1920x1280.jpg" alt="Imagen 6">
            </div>
            <div class="carousel-buttons">
                <button class="carousel-button" id="prev"></button>
                <button class="carousel-button" id="next"></button>
            </div>
        </div>

        <!-- Divider -->
        <div class="full-width-divider"></div>

        <!-- Sección de Comentarios -->
        <div class="comments-section">
            <h2>Comentarios</h2>
            <div class="comments-list" id="comments-list">
                <!-- Los comentarios se cargarán aquí -->
            </div>
            <div class="form-section">
                <textarea id="comment-text" placeholder="Escribe tu comentario aquí..." required></textarea>
                <input type="text" id="comment-author" placeholder="Tu nombre" required>
                <button id="submit-comment">Comentar</button>
            </div>
            <!-- Zona de Comunicaciones con Redes Sociales -->
            <div class="social-links">
                <a href="https://www.facebook.com" target="_blank" title="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="https://www.twitter.com" target="_blank" title="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com" target="_blank" title="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="https://www.linkedin.com" target="_blank" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>
    </div>

    <script>
        const toggleBtn = document.getElementById('toggle-btn');
        const sidebar = document.getElementById('sidebar');
        const content = document.getElementById('content');
        const carouselImages = document.querySelector('.carousel-images');
        const prevBtn = document.getElementById('prev');
        const nextBtn = document.getElementById('next');
        let currentIndex = 0;

        toggleBtn.addEventListener('click', () => {
            sidebar.classList.toggle('open');
            content.classList.toggle('expanded');
        });

        function showNextSlide() {
            currentIndex = (currentIndex + 1) % carouselImages.children.length;
            carouselImages.style.transform = `translateX(-${currentIndex * 100}%)`;
        }

        function showPrevSlide() {
            currentIndex = (currentIndex - 1 + carouselImages.children.length) % carouselImages.children.length;
            carouselImages.style.transform = `translateX(-${currentIndex * 100}%)`;
        }

        prevBtn.addEventListener('click', showPrevSlide);
        nextBtn.addEventListener('click', showNextSlide);

        setInterval(showNextSlide, 3000); // Cambia la imagen cada 3 segundos

        document.addEventListener('DOMContentLoaded', () => {
            const commentsList = document.getElementById('comments-list');
            const submitButton = document.getElementById('submit-comment');

            // Función para cargar comentarios
            function loadComments() {
                const comments = JSON.parse(localStorage.getItem('comments')) || [];
                commentsList.innerHTML = '';
                comments.forEach(comment => {
                    const commentElement = document.createElement('div');
                    commentElement.className = 'comment';
                    commentElement.innerHTML = `
                        <div class="author">${comment.author}:</div>
                        <div class="text">${comment.text}</div>
                        <button onclick="deleteComment('${comment.id}')">Eliminar</button>
                    `;
                    commentsList.appendChild(commentElement);
                });
            }

            // Función para agregar un nuevo comentario
            function addComment(author, text) {
                const comments = JSON.parse(localStorage.getItem('comments')) || [];
                const id = new Date().getTime().toString();
                comments.push({ id, author, text });
                localStorage.setItem('comments', JSON.stringify(comments));
                loadComments();
            }

            // Función para eliminar un comentario
            window.deleteComment = function(id) {
                let comments = JSON.parse(localStorage.getItem('comments')) || [];
                comments = comments.filter(comment => comment.id !== id);
                localStorage.setItem('comments', JSON.stringify(comments));
                loadComments();
            }

            // Event listener para el botón de comentar
            submitButton.addEventListener('click', () => {
                const author = document.getElementById('comment-author').value.trim();
                const text = document.getElementById('comment-text').value.trim();
                if (author && text) {
                    addComment(author, text);
                    document.getElementById('comment-author').value = '';
                    document.getElementById('comment-text').value = '';
                } else {
                    alert('Por favor, completa todos los campos.');
                }
            });

            // Cargar comentarios al inicio
            loadComments();
        });
    </script>
    <div id="sfclhr1q9khxtb7tfn484hr2xmcs1m8gnfj"></div>
    <script type="text/javascript" src="https://counter2.optistats.ovh/private/counter.js?c=lhr1q9khxtb7tfn484hr2xmcs1m8gnfj&down=async" async>
    </script><noscript><a href="https://www.contadorvisitasgratis.com" title="contador de visitas gratis para blog">
    <img src="https://counter2.optistats.ovh/private/contadorvisitasgratis.php?c=lhr1q9khxtb7tfn484hr2xmcs1m8gnfj" 
    border="0" title="contador de visitas gratis para blog" alt="contador de visitas gratis para blog"></a></noscript>

</body>
</html>
