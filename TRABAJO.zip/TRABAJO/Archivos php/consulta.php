<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Productos</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #f06, #f90);
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            color: #333;
        }
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 800px;
            margin: 20px;
            text-align: center;
        }
        .form-container h1 {
            margin-bottom: 20px;
            font-size: 28px;
            color: #f06;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        table th {
            background-color: #f06;
            color: #fff;
            text-transform: uppercase;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tr:hover {
            background-color: #f1f1f1;
        }
        .back-btn {
            background-color: #333;
            border: none;
            color: #fff;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-align: center;
            text-decoration: none;
            display: block;
            margin: 30px auto 0;
            width: 100%;
            max-width: 200px;
        }
        .back-btn:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Consulta de Productos</h1>

        <?php
        $conn = new mysqli("localhost", "root", "", "productos");

        if ($conn->connect_error) {
            die("<p class='error'>Conexión fallida: " . $conn->connect_error . "</p>");
        }

        $result = $conn->query("SELECT * FROM postres");

        if ($result->num_rows > 0) {
            echo "<table>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Tipo</th>
                        <th>Ingredientes</th>
                        <th>Precio</th>
                        <th>Fecha</th>
                    </tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['nombre']}</td>
                        <td>{$row['tipo']}</td>
                        <td>{$row['ingredientes']}</td>
                        <td>{$row['precio']}</td>
                        <td>{$row['fecha']}</td>
                      </tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='message'>No hay productos en la base de datos.</p>";
        }

        $conn->close();
        ?>

        <a class="back-btn" href="index.php">Regresar al Menú Principal</a>
    </div>
</body>
</html>
