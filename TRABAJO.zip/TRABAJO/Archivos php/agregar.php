<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Producto</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #e8f4f8;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 600px;
            border: 2px solid #63e3be;
            position: relative;
        }
        .form-container h1 {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
            font-size: 28px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            color: #555;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box;
        }
        .form-group textarea {
            resize: vertical;
        }
        .form-group button {
            background-color: #63e3be;
            border: none;
            color: #fff;
            padding: 12px 25px;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s;
            display: block;
            margin: 20px auto;
        }
        .form-group button:hover {
            background-color: #4dc4a0;
        }
        .form-group .error {
            color: #e60000;
            font-size: 14px;
            margin-top: 5px;
        }
        .message {
            color: #63e3be;
            font-size: 18px;
            text-align: center;
            margin-top: 20px;
        }
        .back-btn {
            background-color: #007bff;
            color: #ffffff;
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
            text-decoration: none;
            display: inline-block;
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
        }
        .back-btn:hover {
            background-color: #0056b3;
            transform: translateX(-50%) translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Agregar Nuevo Producto</h1>
        <?php
        // Conexión a la base de datos
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "productos";

        // Crear conexión
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verificar conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Verificar si se ha enviado el formulario
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Obtener datos del formulario
            $nombre = $_POST['nombre'];
            $ingredientes = $_POST['ingredientes'];
            $precio = $_POST['precio'];
            $tipo = $_POST['tipo'];
            $fecha = $_POST['fecha'];

            // Preparar y ejecutar la consulta
            $sql = "INSERT INTO postres (nombre, ingredientes, precio, tipo, fecha) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                die("Error al preparar la consulta: " . $conn->error);
            }

            $stmt->bind_param("sssss", $nombre, $ingredientes, $precio, $tipo, $fecha);

            if ($stmt->execute()) {
                echo "<p class='message'>¡Producto agregado con éxito!</p>";
            } else {
                echo "<p class='message'>Error al agregar el producto: " . $stmt->error . "</p>";
            }

            // Cerrar la declaración y la conexión
            $stmt->close();
        }

        $conn->close();
        ?>
        <form action="" method="POST">
            <div class="form-group">
                <label for="nombre">Nombre del Producto</label>
                <input type="text" id="nombre" name="nombre" required>
                <div class="error" id="nombre-error"></div>
            </div>
            <div class="form-group">
                <label for="ingredientes">Ingredientes</label>
                <textarea id="ingredientes" name="ingredientes" required></textarea>
                <div class="error" id="ingredientes-error"></div>
            </div>
            <div class="form-group">
                <label for="precio">Precio</label>
                <input type="number" id="precio" name="precio" step="0.01" required>
                <div class="error" id="precio-error"></div>
            </div>
            <div class="form-group">
                <label>Tipo</label>
                <div class="radio-group">
                    <label><input type="radio" name="tipo" value="pastel" required> Pastel</label>
                    <label><input type="radio" name="tipo" value="cupcake" required> Cupcake</label>
                    <label><input type="radio" name="tipo" value="galleta" required> Galleta</label>
                    <label><input type="radio" name="tipo" value="postre" required> Postre</label>
                </div>
                <div class="error" id="tipo-error"></div>
            </div>
            <div class="form-group">
                <label for="fecha">Fecha</label>
                <input type="date" id="fecha" name="fecha" required>
                <div class="error" id="fecha-error"></div>
            </div>
            <div class="form-group">
                <button type="submit">Agregar Producto</button>
            </div>
        </form>
    </div>
    <!-- Botón de Regreso -->
    <a class="back-btn" href="index.php">Regresar al Menú Principal</a>
</body>
</html>
