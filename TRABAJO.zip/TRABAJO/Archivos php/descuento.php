<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario con Cálculos y Condiciones</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e2e2e2;
            margin: 0;
            padding: 20px;
        }
        .form-section {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }
        h1 {
            font-size: 24px;
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        input[type="checkbox"] {
            margin-right: 10px;
        }
        input[type="number"] {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ddd;
            width: 100%;
            box-sizing: border-box;
        }
        button {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            cursor: pointer;
            padding: 12px 20px;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
            margin-top: 10px;
        }
        button:hover {
            background-color: #45a049;
        }
        .product-container {
            margin-bottom: 20px;
        }
        .product-container label {
            margin-left: 5px;
        }
        #result {
            margin-top: 20px;
            font-size: 20px;
            font-weight: 700;
            text-align: center;
            color: #4CAF50;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 30px;
            font-size: 16px;
        }
        .back-link a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="form-section">
        <h1>Formulario de Compra</h1>
        <form id="price-form" method="post">
            <div class="product-container">
                <input type="checkbox" id="product1" name="products[]" value="350">
                <label for="product1">Tarta de Manzana - $350</label>
                
                <input type="checkbox" id="product2" name="products[]" value="250">
                <label for="product2">Helado de Chocolate - $250</label>
                
                <input type="checkbox" id="product3" name="products[]" value="200">
                <label for="product3">Galletas de Chocolate - $200</label>
                
                <input type="checkbox" id="product4" name="products[]" value="150">
                <label for="product4">Pudín de Vainilla - $150</label>

                <input type="checkbox" id="product5" name="products[]" value="400">
                <label for="product5">Cheesecake - $400</label>
            </div>

            <label for="quantity">Cantidad (de cada producto):</label>
            <input type="number" id="quantity" name="quantity" min="1" value="1" required>

            <button type="submit">Calcular Total</button>
        </form>
        <div id="result"></div>
    </div>

    <div class="back-link">
        <a href="index.php">Regresar a la Página Principal</a>
    </div>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $products = isset($_POST['products']) ? $_POST['products'] : [];
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        $total = 0;
        $discount = 0;

        // Calcular el total de los productos seleccionados
        foreach ($products as $price) {
            $total += (float)$price;
        }
        $total *= $quantity;

        // Aplicar descuento
        if (count($products) > 2) { // Si se seleccionan más de 2 productos
            $discount = 0.1; // 10% de descuento
        }

        $totalWithDiscount = $total - ($total * $discount);

        echo "<script>document.getElementById('result').innerText = 'Total desde PHP: $' + " . json_encode(number_format($totalWithDiscount, 2)) . ";</script>";
    }
    ?>

    <script>
        document.getElementById('price-form').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const quantity = parseInt(document.getElementById('quantity').value, 10);
            const checkboxes = document.querySelectorAll('input[name="products[]"]:checked');
            let total = 0;
            let discount = 0;

            checkboxes.forEach(checkbox => {
                total += parseFloat(checkbox.value);
            });
            total *= quantity;

            // Aplicar descuento
            if (checkboxes.length > 2) { // Si se seleccionan más de 2 productos
                discount = 0.1; // 10% de descuento
            }

            const totalWithDiscount = total - (total * discount);

            document.getElementById('result').innerText = 'Total a pagar: $' + totalWithDiscount.toFixed(2);
        });
    </script>
</body>
</html>
