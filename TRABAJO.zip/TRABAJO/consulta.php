<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Productos</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #e8f4f8;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            color: #333;
            position: relative;
        }
        .form-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 1000px; /* Aumento del ancho máximo del formulario */
            margin: 20px;
            text-align: center;
        }
        .form-container h1 {
            margin-bottom: 20px;
            color: #ff69b4;
            font-size: 28px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        table th, table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        table th {
            background-color: #a5d6a7; /* Verde pastel para encabezados */
            color: #fff;
            text-transform: uppercase;
        }
        table tr:nth-child(even) {
            background-color: #c8e6c9; /* Verde pastel muy claro para filas pares */
        }
        table tr:hover {
            background-color: #b9fbc0; /* Verde pastel más brillante para hover */
        }
        .back-btn {
            background-color: #007bff;
            border: none;
            color: #fff;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            margin-top: 30px;
        }
        .back-btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Consulta de Productos</h1>

        <?php
        $conn = new mysqli("localhost", "root", "", "productos");

        if ($conn->connect_error) {
            die("<p class='error'>Conexión fallida: " . $conn->connect_error . "</p>");
        }

        $result = $conn->query("SELECT * FROM postres");

        if ($result->num_rows > 0) {
            echo "<table>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Tipo</th>
                        <th>Ingredientes</th>
                        <th>Precio</th>
                        <th>Fecha</th>
                    </tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['nombre']}</td>
                        <td>{$row['tipo']}</td>
                        <td>{$row['ingredientes']}</td>
                        <td>{$row['precio']}</td>
                        <td>{$row['fecha']}</td>
                      </tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='message'>No hay productos en la base de datos.</p>";
        }

        $conn->close();
        ?>

        <a class="back-btn" href="index.php">Regresar al Menú Principal</a>
    </div>
</body>
</html>
